geo.mean <- function(x) {
  geometric.mean <- exp(mean(log(x)))
  return(geometric.mean)
}