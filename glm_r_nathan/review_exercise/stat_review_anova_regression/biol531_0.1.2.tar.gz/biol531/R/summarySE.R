#' Summary With Standard Error and Confidence Interval
#'
#' This function produces a data frame with summary statistics for a variable from a data frame. The summary includes standard deviation, sample size, standard error, and 95 percent confidence limits.
#' @param df The data frame containing the variable and groups
#' @param measurevar The variable to summarize
#' @param groups A vector with names of one or more grouping variables.
#' @keywords summary
#' @export
#' @examples
#' summarySE()

summarySE <- function (df, measurevar, groups)
{
  df <- data.frame(df)
  if (length(groups) == 1) {
    grp.list <- list(df[, groups])
    names(grp.list) <- groups
  }
  else grp.list <- as.list(df[, groups])
  output <- aggregate(df[, measurevar], by = grp.list, FUN = mean)
  names(output)[length(groups) + 1] <- "mean"
  output$sd <- aggregate(df[, measurevar], by = grp.list, FUN = sd)[,length(groups) + 1]
  output$n <- aggregate(df[, measurevar], by = grp.list, FUN = length)[,length(groups) + 1]
  output$se <- output$sd/sqrt(output$n)
  output$lower <- output$mean - qt(0.975, output$n - 1) * output$se
  output$upper <- output$mean + qt(0.975, output$n - 1) * output$se
  return(output)
}
