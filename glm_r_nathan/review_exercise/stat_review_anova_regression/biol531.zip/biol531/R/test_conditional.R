#' Differences Between Levels Of One Variable, Conditional On Another
#'
#' This function tests for differences in mean for one variable from an interaction at each level of the other.
#' @param mod The fitted model containing the interaction.
#' @param cond.var The condition grouping variable, which will be held constant.
#' @param test.var The test grouping variable, used for grouping in Tukey tests.
#' @keywords posthoc
#' @export
#' @examples
#' test.conditional()

test.conditional <- function(mod, cond.var, test.var) {
  levels.test <- mod$xlevels[[test.var]]
  levels.cond <- mod$xlevels[[cond.var]]
  tmp <- expand.grid(levels.test, levels.cond)
  colnames(tmp) <- c(test.var, cond.var)
  X <- model.matrix(formula(mod)[-2], data=tmp)
  Tukey <- multcomp::contrMat(table(mod$model[test.var]), "Tukey")
  K <- c()
  num.levels <- length(levels.test)
  num.cond <- length(levels.cond)
  for(i in 0:(num.cond-1)){
    leads <- i
    follows <- num.cond - 1 - i
    K.tmp <- cbind(matrix(0, nrow = nrow(Tukey), ncol = leads*ncol(Tukey)), Tukey, matrix(0, nrow = nrow(Tukey), ncol = follows*ncol(Tukey)))
    rownames(K.tmp) <- paste(levels.cond[i+1], row.names(K.tmp), sep = ":")
    K <- rbind(K, K.tmp)
  }

  colnames(K) <- rep(colnames(Tukey), num.cond)
  tests <- multcomp::glht(mod, linfct = K %*% X)
  return(tests)
}
