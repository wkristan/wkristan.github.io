#' Standardized Regression Coefficients
#' 
#' Calculate standardized regression coefficients from a fitted model.
#' @param MOD A fitted model.
#' @keywords regression
#' @export
#' @examples 
#' stdcoeff()

stdcoeff <- function(MOD) {
b <- summary(MOD)$coef[-1, 1]
sx <- sapply(MOD$model[-1], sd)
sy <- sapply(MOD$model[1], sd)
beta <- b * sx/sy
return(beta) }